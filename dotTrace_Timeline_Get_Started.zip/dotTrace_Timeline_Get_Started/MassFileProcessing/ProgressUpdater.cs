﻿namespace MassFileProcessing
{
    internal class ProgressUpdater
    {
        public int TotalFiles;
        public int CurrentFileNmb;
    }
}