﻿using Microsoft.AspNetCore.Mvc;
using GreetingComposerService.Models;
using GreetingComposerService.Services; // For IFactServiceClient
using System.Threading.Tasks;

namespace GreetingComposerService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GreetingController : ControllerBase
    {
        private readonly IFactServiceClient _factServiceClient;
        private readonly ILogger<GreetingController> _logger;

        public GreetingController(IFactServiceClient factServiceClient, ILogger<GreetingController> logger)
        {
            _factServiceClient = factServiceClient;
            _logger = logger;
        }

        [HttpGet("{name}")]
        public async Task<ActionResult<GreetingResponse>> GetGreeting(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return BadRequest("Name cannot be empty.");
            }

            _logger.LogInformation("Greeting requested for name: {Name}", name);

            string fact = await _factServiceClient.GetRandomFactAsync();

            string greetingMessage = $"Hello, {name}! Here's a fact for you: \"{fact}\"";

            // Simulate some work in composing the greeting
            for (int i = 0; i < 50000; i++) { /* some dummy loop */ }

            return Ok(new GreetingResponse
            {
                Greeting = greetingMessage,
                Timestamp = DateTime.UtcNow
            });
        }
    }
}