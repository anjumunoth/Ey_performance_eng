﻿using Microsoft.AspNetCore.Mvc;

namespace GreetingComposerService.Controllers
{
    [ApiController]
    [Route("[controller]")] // Will be /health
    public class HealthController : ControllerBase
    {
        private readonly ILogger<HealthController> _logger;

        public HealthController(ILogger<HealthController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult GetHealth()
        {
            _logger.LogDebug("Health check requested for GreetingComposerService.");
            // You could add a check here to see if it can ping the FactApiService
            // For now, just basic health.
            return Ok(new { Status = "Healthy", Service = "GreetingComposerService", Timestamp = DateTime.UtcNow });
        }
    }
}