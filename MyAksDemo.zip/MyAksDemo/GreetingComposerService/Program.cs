using GreetingComposerService.Services; // For FactServiceClient and FactServiceOptions

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// Configure FactServiceOptions from appsettings.json (section "FactService")
builder.Services.Configure<FactServiceOptions>(builder.Configuration.GetSection("FactService"));

// Register HttpClient for IFactServiceClient
// This sets up HttpClientFactory for proper HttpClient lifetime management
builder.Services.AddHttpClient<IFactServiceClient, FactServiceClient>()
    .SetHandlerLifetime(TimeSpan.FromMinutes(5)) // Example: Configure handler lifetime
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        AllowAutoRedirect = false,
        UseCookies = false
        // Add other HttpClientHandler settings if needed
    });
// You can add Polly policies here for resilience (e.g. .AddTransientHttpErrorPolicy(...))


builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment() || Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development_Swagger")
{
    app.UseSwagger();
    app.UseSwaggerUI();
    if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development_Swagger")
    {
        Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
    }
}

// app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();