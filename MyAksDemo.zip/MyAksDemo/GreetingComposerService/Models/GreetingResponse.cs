﻿namespace GreetingComposerService.Models
{
    public class GreetingResponse
    {
        public string Greeting { get; set; }
        public DateTime Timestamp { get; set; }
    }
}