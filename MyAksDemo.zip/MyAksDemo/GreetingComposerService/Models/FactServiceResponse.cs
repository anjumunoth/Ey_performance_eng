﻿namespace GreetingComposerService.Models
{
    // This should match the structure of FactApiService.Models.FactResponse
    public class FactServiceResponse
    {
        public string Fact { get; set; }
        // Timestamp can be ignored if not needed for deserialization here
    }
}