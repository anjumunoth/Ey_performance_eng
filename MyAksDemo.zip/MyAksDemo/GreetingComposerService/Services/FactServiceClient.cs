﻿using System.Net.Http;
using System.Net.Http.Json; // For ReadFromJsonAsync
using System.Threading.Tasks;
using GreetingComposerService.Models; // For FactServiceResponse
using Microsoft.Extensions.Options;   // For IOptions

namespace GreetingComposerService.Services
{
    public class FactServiceOptions
    {
        public string BaseUrl { get; set; }
    }

    public interface IFactServiceClient
    {
        Task<string> GetRandomFactAsync();
    }

    public class FactServiceClient : IFactServiceClient
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<FactServiceClient> _logger;
        private readonly string _factServiceUrl;

        public FactServiceClient(HttpClient httpClient, IOptions<FactServiceOptions> options, ILogger<FactServiceClient> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
            _factServiceUrl = !string.IsNullOrWhiteSpace(options.Value?.BaseUrl)
                              ? $"{options.Value.BaseUrl.TrimEnd('/')}/api/fact"
                              : "http://factapiservice/api/fact"; // Default for in-cluster, or needs configuration

            _logger.LogInformation("FactServiceClient configured to use URL: {Url}", _factServiceUrl);
        }

        public async Task<string> GetRandomFactAsync()
        {
            try
            {
                _logger.LogInformation("Requesting fact from {Url}", _factServiceUrl);
                // Example of adding a custom header if needed
                // _httpClient.DefaultRequestHeaders.Add("X-Custom-Header", "GreetingComposer");

                var response = await _httpClient.GetAsync(_factServiceUrl);
                response.EnsureSuccessStatusCode(); // Throws if not 2xx

                var factResponse = await response.Content.ReadFromJsonAsync<FactServiceResponse>();
                if (factResponse != null && !string.IsNullOrEmpty(factResponse.Fact))
                {
                    _logger.LogInformation("Fact received: {Fact}", factResponse.Fact);
                    return factResponse.Fact;
                }
                _logger.LogWarning("Received empty or null fact from FactApiService.");
                return "Hmm, I couldn't fetch a fact right now.";
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Error calling FactApiService at {Url}.", _factServiceUrl);
                return "Oops! I had trouble getting a fact.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error in FactServiceClient at {Url}.", _factServiceUrl);
                return "An unexpected error occurred while fetching a fact.";
            }
        }
    }
}