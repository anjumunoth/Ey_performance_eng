﻿namespace FactApiService.Models
{
    public class FactResponse
    {
        public string Fact { get; set; }
        public DateTime Timestamp { get; set; }

        public FactResponse(string fact)
        {
            Fact = fact;
            Timestamp = DateTime.UtcNow;
        }
    }
}