using FactApiService.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddSingleton<IFactService, FactService>(); // Register our fact service

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment() || Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development_Swagger")
{
    app.UseSwagger();
    app.UseSwaggerUI();
    // Ensure ASPNETCORE_ENVIRONMENT is set to Development for Swagger to work if forced
    if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development_Swagger")
    {
        Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development");
    }
}

// app.UseHttpsRedirection(); // Typically handled by ingress in K8s

app.UseAuthorization();

app.MapControllers(); // This maps attribute-routed controllers

app.Run();