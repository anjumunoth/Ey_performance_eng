﻿using Microsoft.AspNetCore.Mvc;

namespace FactApiService.Controllers
{
    [ApiController]
    [Route("[controller]")] // Will be /health
    public class HealthController : ControllerBase
    {
        private readonly ILogger<HealthController> _logger;

        public HealthController(ILogger<HealthController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult GetHealth()
        {
            _logger.LogDebug("Health check requested for FactApiService.");
            // In a real app, you might check dependencies here
            return Ok(new { Status = "Healthy", Service = "FactApiService", Timestamp = DateTime.UtcNow });
        }
    }
}