﻿using Microsoft.AspNetCore.Mvc;
using FactApiService.Models;
using FactApiService.Services;
using System.Threading.Tasks;

namespace FactApiService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FactController : ControllerBase
    {
        private readonly IFactService _factService;
        private readonly ILogger<FactController> _logger;

        public FactController(IFactService factService, ILogger<FactController> logger)
        {
            _factService = factService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<FactResponse>> GetFact()
        {
            _logger.LogInformation("Fact endpoint called.");
            string fact = await _factService.GetRandomFactAsync();
            return Ok(new FactResponse(fact));
        }

        // Endpoint for testing autoscaling/GC
        [HttpGet("complex")]
        public async Task<ActionResult<FactResponse>> GetComplexFact([FromQuery] int complexity = 1)
        {
            _logger.LogInformation("Complex fact endpoint called with complexity {Complexity}.", complexity);
            if (complexity < 1) complexity = 1;
            if (complexity > 10) complexity = 10; // Cap complexity for safety

            string fact = await _factService.GetComplexFactAsync(complexity);
            return Ok(new FactResponse(fact));
        }
    }
}