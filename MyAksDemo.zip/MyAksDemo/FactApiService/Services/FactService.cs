﻿using System;
using System.Collections.Generic;
using System.Linq; // Required for OrderBy
using System.Threading.Tasks;

namespace FactApiService.Services
{
    public interface IFactService
    {
        Task<string> GetRandomFactAsync();
        public Task<string> GetComplexFactAsync(int complexity);
    }

    public class FactService : IFactService
    {
        private static readonly List<string> _facts = new List<string>
        {
            "The sky is blue on a clear day because of Rayleigh scattering.",
            "Honey never spoils.",
            "A group of flamingos is called a 'flamboyance'.",
            "Octopuses have three hearts.",
            "Bananas are berries, but strawberries aren't.",
            "The shortest war in history was between Britain and Zanzibar on August 27, 1896. Zanzibar surrendered after 38 minutes.",
            "An ostrich's eye is bigger than its brain.",
            "Cows have best friends and can become stressed when they are separated.",
            "It's impossible for most people to lick their own elbow.",
            "A crocodile cannot stick its tongue out."
        };

        private readonly Random _random = new Random();
        private readonly ILogger<FactService> _logger;

        public FactService(ILogger<FactService> logger)
        {
            _logger = logger;
        }

        public Task<string> GetRandomFactAsync()
        {
            // Simulate a little work or potential I/O
            // await Task.Delay(TimeSpan.FromMilliseconds(_random.Next(50, 150))); // Optional: simulate latency

            int index = _random.Next(_facts.Count);
            var fact = _facts[index];
            _logger.LogInformation("Providing fact: {Fact}", fact);
            return Task.FromResult(fact);
        }

        // Example of how you might add a method to simulate memory/CPU for testing
        public async Task<string> GetComplexFactAsync(int complexity = 1)
        {
            _logger.LogInformation("Generating complex fact with complexity {Complexity}", complexity);
            List<string> tempFacts = new List<string>(_facts); // Create a copy to operate on

            for (int i = 0; i < complexity * 100000; i++)
            {
                // Simulate CPU work
                tempFacts.Sort(); // Sort repeatedly
                if (i % 10000 == 0) await Task.Yield(); // Yield to prevent blocking for too long
            }

            // Simulate memory allocation
            if (complexity > 2)
            {
                try
                {
                    byte[] largeArray = new byte[complexity * 5 * 1024 * 1024]; // Allocate some MB
                    largeArray[0] = 1; // Ensure it's used
                    _logger.LogInformation("Allocated {Size}MB for complex fact.", complexity * 5);
                }
                catch (OutOfMemoryException ex)
                {
                    _logger.LogError(ex, "OOM allocating memory for complex fact.");
                }
            }

            return await GetRandomFactAsync(); // Return a normal random fact after simulation
        }
    }
}